#!/bin/bash

# Print numbers from 10 to 0
for (( counter=10; counter>0; counter-- ))
do
echo -n "$counter "
printf "\n"