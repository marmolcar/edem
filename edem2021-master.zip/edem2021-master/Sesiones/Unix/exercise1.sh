#!/bin/bash

# Add two numeric value

a=1+1
echo b