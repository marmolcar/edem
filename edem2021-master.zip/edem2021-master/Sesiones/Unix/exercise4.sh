#!/bin/bash

# Read and print your name
echo "Enter Your Name"
read name
echo "Welcome name to LinuxHint"