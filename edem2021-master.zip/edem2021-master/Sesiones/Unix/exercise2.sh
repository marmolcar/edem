#!/bin/bash

# Print positive numbers between -10 and 10
valid=true
count=1
while [ count>0 ]
do
echo $count
done